enum VerifyEmailType { registration, forgotPassword }
